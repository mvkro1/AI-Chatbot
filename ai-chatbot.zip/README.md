# AI Chatbot

An AI-powered chatbot that integrates with Telegram and Discord. Uses OpenAI’s GPT model for responses.